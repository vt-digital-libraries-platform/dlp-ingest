import boto3, json, os, uuid
import pandas as pd
from datetime import datetime, timezone
from io import StringIO


s3_client = boto3.client("s3")

def get_matching_s3_keys(bucket, prefix="", suffix=""):
    s3 = boto3.client("s3")
    kwargs = {"Bucket": bucket, "Prefix": prefix}
    matches = []
    while True:
        resp = s3.list_objects_v2(**kwargs)
        try:
            contents = resp["Contents"]
        except KeyError:
            return
        for obj in contents:
            key = obj["Key"]
            if key.startswith(prefix) and key.endswith(suffix):
                matches.append(key)
        try:
            kwargs["ContinuationToken"] = resp["NextContinuationToken"]
        except KeyError:
            break
    return matches


def csv_to_dataframe(csv_path):
    df = pd.read_csv(
        csv_path,
        na_values='NaN',
        keep_default_na=False,
        encoding='utf-8',
        dtype={
            'start_date': str,
            'end_date': str})
    return df

def get_checksum_file_paths(s3_bucket, collection_path):
    checksum_files = get_matching_s3_keys(s3_bucket, os.path.join(collection_path,"checksum"), suffix=".csv")
    return checksum_files


def get_fileList(s3_bucket, checksum_file_path):
    filename = os.path.basename(checksum_file_path)
    dataframe = None
    try:
        response = s3_client.get_object(Bucket=s3_bucket, Key=checksum_file_path)
        data = response["Body"].read().decode('utf-8')
        dataframe = pd.read_csv(StringIO(data))
    except Exception as e:
        print(e)
    return dataframe


def lambda_handler(event, context):
    collection_identifier = event.get('COLLECTION_IDENTIFIER')
    fixity_table_name = event.get('FIXITY_TABLE_NAME') or os.getenv('FIXITY_TABLE_NAME')
    s3_bucket = event.get('S3_BUCKET_NAME') or os.getenv('S3_BUCKET_NAME')
    s3_prefix = event.get('S3_PREFIX') or os.getenv('S3_PREFIX')
    collection_path = os.path.join(s3_prefix, collection_identifier)
    checksum_file_paths = get_checksum_file_paths(s3_bucket, collection_path)

    file_list = []
    for path in checksum_file_paths:
        file_list = get_fileList(s3_bucket, path)

        for idx, record in file_list.iterrows():
            filename = os.path.basename(record['File Path'])
            obj_keys = get_matching_s3_keys(s3_bucket, collection_path, filename)
            obj = obj_keys[0] if obj_keys else None
            if not obj:
                # TODO: log file not found
                print(f"File not found: {obj}")
                continue

            metadata = s3_client.head_object(Bucket=s3_bucket, Key=obj)
            mime_type = metadata['ContentType']
            ingested_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            print(ingested_date)
            print()
            file_record = {
                'id': str(uuid.uuid4()),
                'collection_identifier': collection_identifier,
                'file_name': record['Filename'],
                'file_size': record['File Size'],
                'file_extension': record['File Extension'],
                'file_type': mime_type,
                'orig_file_path': record['File Path'],
                's3_file_path': obj,
                'sha1': record['SHA1 Hash'],
                'md5': record['MD5 Hash'],
                'created_date': record['Created Date'],
                'ingested_date': ingested_date
            }
            # 's3_file_metadata': json.dumps(metadata),
                
            dynamo_resource = boto3.resource("dynamodb", region_name="us-east-1")
            fixity_table = dynamo_resource.Table(fixity_table_name)
            fixity_table.put_item(Item=file_record)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Process completed.",
        }),
    }
        

